package com.example.act2tema5;

public class Animales {
    private String title;

    private String image;

    public Animales(String title, String image) {

        this.title = title;

        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }
}